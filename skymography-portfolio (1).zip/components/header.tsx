"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import Image from "next/image"

export default function Header() {
  const pathname = usePathname()

  return (
    <header className="header">
      <Link href="/" className="logo">
        <Image
          src="https://i.postimg.cc/tT6FMcpS/2.png"
          alt="Skymography Logo"
          className="logo-img"
          width={27}
          height={27}
          priority
        />
        bull.edits_
      </Link>

      <nav className="nav">
        <Link href="/" className={pathname === "/" ? "active" : ""}>
          HOME
        </Link>
        <Link href="/contact" className={pathname === "/contact" ? "active" : ""}>
          CONTACT
        </Link>
        <Link href="/about" className={pathname === "/about" ? "active" : ""}>
          ABOUT
        </Link>
      </nav>
    </header>
  )
}
