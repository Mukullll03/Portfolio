import Image from "next/image"

export default function Footer() {
  return (
    <footer className="footer">
      <div className="social-icons">
        <a
          href="https://www.instagram.com/skymography/"
          target="_blank"
          rel="noopener noreferrer"
          className="social-icon"
          aria-label="Visit Instagram profile"
        >
          <Image src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="Instagram" width={28} height={28} />
        </a>
        <a
          href="https://www.youtube.com/Skymography"
          target="_blank"
          rel="noopener noreferrer"
          className="social-icon"
          aria-label="Visit YouTube channel"
        >
          <Image src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube" width={28} height={28} />
        </a>
        <a
          href="https://twitter.com/skymography"
          target="_blank"
          rel="noopener noreferrer"
          className="social-icon"
          aria-label="Visit Twitter profile"
        >
          <Image src="https://cdn-icons-png.flaticon.com/512/733/733579.png" alt="Twitter" width={28} height={28} />
        </a>
        <a
          href="https://www.linkedin.com/in/skymography"
          target="_blank"
          rel="noopener noreferrer"
          className="social-icon"
          aria-label="Visit LinkedIn profile"
        >
          <Image src="https://cdn-icons-png.flaticon.com/512/174/174857.png" alt="LinkedIn" width={28} height={28} />
        </a>
      </div>
    </footer>
  )
}
