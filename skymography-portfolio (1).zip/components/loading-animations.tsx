"use client"

import { useEffect } from "react"

export default function LoadingAnimations() {
  useEffect(() => {
    function initLoadingAnimations() {
      if (!("IntersectionObserver" in window)) {
        // Fallback for older browsers
        document.querySelectorAll(".loading").forEach((el) => {
          el.classList.add("loaded")
        })
        return
      }

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("loaded")
              observer.unobserve(entry.target)
            }
          })
        },
        {
          threshold: 0.1,
          rootMargin: "0px 0px -50px 0px",
        },
      )

      document.querySelectorAll(".loading").forEach((el) => {
        observer.observe(el)
      })
    }

    initLoadingAnimations()

    // Add a small delay to ensure smooth initial load
    setTimeout(() => {
      document.querySelectorAll(".loading").forEach((el) => {
        const element = el as HTMLElement
        element.style.transition = "all 0.6s ease"
      })
    }, 100)

    // Prevent zoom on double tap for iOS
    let lastTouchEnd = 0
    const handleTouchEnd = (event: TouchEvent) => {
      const now = new Date().getTime()
      if (now - lastTouchEnd <= 300) {
        event.preventDefault()
      }
      lastTouchEnd = now
    }

    document.addEventListener("touchend", handleTouchEnd, false)

    return () => {
      document.removeEventListener("touchend", handleTouchEnd, false)
    }
  }, [])

  return null
}
