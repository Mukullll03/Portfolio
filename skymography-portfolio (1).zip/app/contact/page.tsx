"use client"

import { useActionState } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import LoadingAnimations from "@/components/loading-animations"
import { submitContactForm, type ContactFormState } from "@/app/actions/contact"

export default function ContactPage() {
  const [state, formAction, isPending] = useActionState<ContactFormState, FormData>(submitContactForm, null)

  return (
    <>
      <Header />
      <LoadingAnimations />

      <main className="container">
        <section className="contact-section loading">
          {/* Left Column - Contact Info */}
          <div className="contact-info">
            <h1 className="contact-title">GET IN TOUCH.</h1>
            <p className="contact-description">
              Feel free to reach out — I'll reply as soon as possible! Whether you need creative video work, clean
              animations, or have a unique vision, I'd love to bring it to life. I work closely with individuals,
              brands, and teams to craft visuals that tell a story and make an impact. <br />
              <br />
              No project is too big or small — just share your idea, and we'll take it from there. Looking forward to
              hearing from you and creating something great together!
            </p>
            <div className="contact-email-section">
              Alternatively, email me at
              <br />
              <a
                href="mailto:mukuluprikar@gmail.com?subject=Let%27s%20Connect&body=Hi%20Mukul%2C%0AI%20wanted%20to%20reach%20out%20about..."
                className="contact-email"
              >
                mukuluprikar@gmail.com
              </a>
            </div>
          </div>

          {/* Right Column - Contact Form */}
          <form className="contact-form" action={formAction}>
            <div className="form-group">
              <label htmlFor="name" className="form-label">
                Name <span className="required">(required)</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                className="form-input"
                required
                disabled={isPending}
                autoComplete="name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email" className="form-label">
                Email Address <span className="required">(required)</span>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                className="form-input"
                required
                disabled={isPending}
                autoComplete="email"
              />
            </div>

            <div className="form-group">
              <label htmlFor="subject" className="form-label">
                Subject <span className="required">(required)</span>
              </label>
              <input
                type="text"
                id="subject"
                name="subject"
                className="form-input"
                required
                disabled={isPending}
                autoComplete="off"
              />
            </div>

            <div className="form-group">
              <label htmlFor="message" className="form-label">
                Message <span className="required">(required)</span>
              </label>
              <textarea
                id="message"
                name="message"
                className="form-textarea"
                required
                disabled={isPending}
                rows={5}
                placeholder="Tell me about your project..."
              />
            </div>

            <button type="submit" className="submit-btn" disabled={isPending}>
              {isPending ? "SENDING..." : "SUBMIT"}
            </button>

            {state && <div className={`message ${state.success ? "success" : "error"}`}>{state.message}</div>}
          </form>
        </section>
      </main>

      <Footer />
    </>
  )
}
