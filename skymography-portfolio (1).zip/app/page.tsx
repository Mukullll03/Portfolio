"use client"

import { useEffect } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import LoadingAnimations from "@/components/loading-animations"
import Image from "next/image"

const portfolioVideos = {
  picasso: "https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  nike: "https://www.youtube.com/embed/hJLMSllzoLA?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  webmd: "https://www.youtube.com/embed/oHg5SJYRHA0?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  psychedelics: "https://www.youtube.com/embed/kJQP7kiw5Fk?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  adidas: "https://www.youtube.com/embed/L_jWHffIx5E?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  creativity: "https://www.youtube.com/embed/9bZkp7q19f0?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  medscape: "https://www.youtube.com/embed/PHgc8Q6qTjc?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  dtx: "https://www.youtube.com/embed/fJ9rUzIMcZQ?autoplay=1&modestbranding=1&showinfo=0&rel=0",
  iceland: "https://www.youtube.com/embed/Hm7vnOC4hoY?autoplay=1&modestbranding=1&showinfo=0&rel=0",
}

const portfolioItems = [
  {
    id: "picasso",
    image: "https://picsum.photos/400/400?random=1",
    description:
      "I Tried Picasso's Daily Routine - A creative exploration of the master's artistic process and daily habits that shaped his revolutionary art",
  },
  {
    id: "nike",
    image: "https://picsum.photos/400/400?random=2",
    description:
      "NIKE - Dynamic brand commercial showcasing athletic excellence, motivation, and the power of sport to inspire greatness",
  },
  {
    id: "webmd",
    image: "https://picsum.photos/400/400?random=3",
    description:
      "WebMD - Educational health content designed to inform and engage audiences with trusted medical information and wellness guidance",
  },
  {
    id: "psychedelics",
    image: "https://picsum.photos/400/400?random=4",
    description:
      "Psychedelics Changed My Life - A personal journey exploring consciousness, transformation, and the profound impact of psychedelic experiences",
  },
  {
    id: "adidas",
    image: "https://picsum.photos/400/400?random=5",
    description:
      "adidas - Inspiring athletic performance through innovative brand storytelling and celebrating the spirit of sport and achievement",
  },
  {
    id: "creativity",
    image: "https://picsum.photos/400/400?random=6",
    description:
      "CREATIVITY - Exploring the boundless world of artistic expression, innovation, and the creative process that drives human imagination",
  },
  {
    id: "medscape",
    image: "https://picsum.photos/400/400?random=7",
    description:
      "Medscape EDUCATION - Professional medical content for healthcare practitioners, providing continuing education and clinical insights",
  },
  {
    id: "dtx",
    image: "https://picsum.photos/400/400?random=8",
    description:
      "DTx - Digital therapeutics revolutionizing healthcare through innovative technology solutions and personalized treatment approaches",
  },
  {
    id: "iceland",
    image: "https://picsum.photos/400/400?random=9",
    description:
      "ICELAND - Breathtaking cinematic journey through stunning Nordic landscapes, capturing the raw beauty and mystique of this incredible country",
  },
]

const instagramPosts = [
  {
    url: "https://www.instagram.com/p/C8xYzQrN5mK/",
    image: "https://images.unsplash.com/photo-1611262588024-d12430b98920?w=400&h=400&fit=crop&crop=center",
  },
  {
    url: "https://www.instagram.com/p/C8vWxQrN2mL/",
    image: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=400&fit=crop&crop=center",
  },
  {
    url: "https://www.instagram.com/p/C8tUvQrN8mM/",
    image: "https://images.unsplash.com/photo-1611605698335-8b1569810432?w=400&h=400&fit=crop&crop=center",
  },
  {
    url: "https://www.instagram.com/p/C8rSqQrN4mN/",
    image: "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=400&h=400&fit=crop&crop=center",
  },
  {
    url: "https://www.instagram.com/p/C8pQoQrN0mO/",
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=400&fit=crop&crop=center",
  },
]

export default function HomePage() {
  useEffect(() => {
    // Portfolio video modal functions
    const openPortfolioVideo = (item: string) => {
      if (navigator.vibrate) {
        navigator.vibrate(50)
      }

      const modal = document.getElementById("videoModal")
      const modalVideo = document.getElementById("modalVideo") as HTMLIFrameElement

      if (portfolioVideos[item as keyof typeof portfolioVideos] && modal && modalVideo) {
        modal.classList.add("active")
        document.body.style.overflow = "hidden"

        setTimeout(() => {
          modalVideo.src = portfolioVideos[item as keyof typeof portfolioVideos]
        }, 50)
      }
    }

    const closeVideoModal = () => {
      const modal = document.getElementById("videoModal")
      const modalVideo = document.getElementById("modalVideo") as HTMLIFrameElement

      if (modal && modalVideo) {
        modalVideo.src = "about:blank"
        modal.classList.remove("active")
        document.body.style.overflow = ""
      }
    }

    const openInstagramPost = (postUrl: string) => {
      if (navigator.vibrate) {
        navigator.vibrate(50)
      }
      window.open(postUrl, "_blank", "noopener,noreferrer")
    }

    // Attach functions to window for onclick handlers
    ;(window as any).openPortfolioVideo = openPortfolioVideo
    ;(window as any).closeVideoModal = closeVideoModal
    ;(window as any).openInstagramPost = openInstagramPost

    // Close modal when clicking outside the video
    const videoModal = document.getElementById("videoModal")
    if (videoModal) {
      videoModal.addEventListener("click", function (e) {
        if (e.target === this) {
          closeVideoModal()
        }
      })
    }

    // Close modal with Escape key
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        closeVideoModal()
      }
    }
    document.addEventListener("keydown", handleKeyDown)

    return () => {
      document.removeEventListener("keydown", handleKeyDown)
    }
  }, [])

  return (
    <>
      <Header />
      <LoadingAnimations />

      <main className="container">
        {/* Animation Showreel Section */}
        <section className="showreel-section loading">
          <h2 className="section-title">ANIMATION SHOWREEL</h2>
          <div className="video-container">
            <iframe
              src="https://www.youtube.com/embed/I_X5U_cMsLc?vq=hd1080&modestbranding=1&showinfo=0&rel=0&theme=light&color=white&autoplay=0"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              loading="lazy"
              title="Animation Showreel"
            />
          </div>
        </section>

        <div className="fade-line loading"></div>

        {/* Portfolio Section */}
        <section className="portfolio-section loading">
          <h2 className="section-title">PORTFOLIO EXAMPLES</h2>
          <div className="portfolio-grid">
            {portfolioItems.map((item) => (
              <div
                key={item.id}
                className="portfolio-item"
                onClick={() => (window as any).openPortfolioVideo(item.id)}
                role="button"
                tabIndex={0}
                aria-label={`View ${item.id} portfolio video`}
              >
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={`${item.id} Portfolio Thumbnail`}
                  width={400}
                  height={400}
                />
                <div className="portfolio-overlay">
                  <div className="portfolio-description">{item.description}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="fade-line1 loading"></div>

        {/* Instagram Section */}
        <section className="instagram-section loading">
          <h2 className="section-title">INSTAGRAM</h2>
          <div className="instagram-grid">
            {instagramPosts.map((post, index) => (
              <div
                key={index}
                className="instagram-item"
                onClick={() => (window as any).openInstagramPost(post.url)}
                role="button"
                tabIndex={0}
                aria-label={`View Instagram post ${index + 1}`}
              >
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={`Instagram Post ${index + 1}`}
                  width={400}
                  height={400}
                />
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Video Modal */}
      <div id="videoModal" className="video-modal">
        <div className="video-modal-content">
          <button className="video-close" onClick={() => (window as any).closeVideoModal()} aria-label="Close video">
            &times;
          </button>
          <iframe
            id="modalVideo"
            src="about:blank"
            allowFullScreen
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          />
        </div>
      </div>

      <Footer />
    </>
  )
}
