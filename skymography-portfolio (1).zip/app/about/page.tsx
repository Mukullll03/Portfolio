import Header from "@/components/header"
import Footer from "@/components/footer"
import LoadingAnimations from "@/components/loading-animations"
import Image from "next/image"
import Link from "next/link"

export default function AboutPage() {
  return (
    <>
      <Header />
      <LoadingAnimations />

      <main className="container">
        <section className="about-section loading">
          {/* Left Column - Profile Image */}
          <div className="about-image">
            <Image
              src="https://i.postimg.cc/vTX5wXvF/img.jpg"
              alt="Sky - Motion Graphics Animator"
              className="profile-img"
              width={450}
              height={600}
              priority
            />
          </div>

          {/* Right Column - About Content */}
          <div className="about-content">
            <h1 className="about-title">ABOUT.</h1>

            <p className="about-greeting">Hi!</p>

            <p className="about-text">
              My name is Mukul and I'm a video editor. I have been working in motion design for over 3 years, ranging
              from 3d animations to entire documentaries, with everything in between.
            </p>

            <p className="about-text">
              Working across as many styles as I can is at the heart of what I do. I look up to creatives who explore
              new mediums and possibilities — that's what keeps this career exciting. My greatest competition is the
              unknown, and I plan to keep exploring, always :)
            </p>

            <p className="about-text">
              If you have any questions or just want to say hi back, feel free to reach out through the contact page{" "}
              <Link href="/contact" className="contact-link">
                here
              </Link>
              . I look forward to hearing from you!
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
