"use server"

import { z } from "zod"

const contactSchema = z.object({
  name: z.string().min(1, "Name is required").max(100, "Name is too long"),
  email: z.string().email("Please enter a valid email address"),
  subject: z.string().min(1, "Subject is required").max(200, "Subject is too long"),
  message: z.string().min(10, "Message must be at least 10 characters").max(2000, "Message is too long"),
})

export type ContactFormState = {
  success: boolean
  message: string
} | null

export async function submitContactForm(prevState: ContactFormState, formData: FormData): Promise<ContactFormState> {
  try {
    // Check if formData exists
    if (!formData) {
      return {
        success: false,
        message: "Form data is missing. Please try again.",
      }
    }

    // Extract and validate form data
    const rawData = {
      name: formData.get("name"),
      email: formData.get("email"),
      subject: formData.get("subject"),
      message: formData.get("message"),
    }

    // Check if all fields are present
    if (!rawData.name || !rawData.email || !rawData.subject || !rawData.message) {
      return {
        success: false,
        message: "All fields are required. Please fill out the complete form.",
      }
    }

    // Validate form data
    const validatedData = contactSchema.parse(rawData)

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Here you would typically:
    // 1. Save to database
    // 2. Send email notification
    // 3. Send auto-reply to user

    // For now, we'll just log the data
    console.log("Contact form submission:", validatedData)

    // You could integrate with email services like:
    // - Resend
    // - SendGrid
    // - Nodemailer
    // - AWS SES

    return {
      success: true,
      message: "Thanks! Your message has been sent successfully. I'll get back to you soon!",
    }
  } catch (error) {
    console.error("/wowsite/actions/contact error:", error)

    if (error instanceof z.ZodError) {
      return {
        success: false,
        message: error.errors[0].message,
      }
    }

    return {
      success: false,
      message: "Sorry, there was an error sending your message. Please try again or email me directly.",
    }
  }
}
